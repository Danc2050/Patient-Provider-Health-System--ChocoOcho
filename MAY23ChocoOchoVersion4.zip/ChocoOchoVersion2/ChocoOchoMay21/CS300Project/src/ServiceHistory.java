public class ServiceHistory {
    /*protected Node s_root;
    protected String comments;
    protected String service_date;
    protected String p_name;
    protected String m_name;
    protected int p_num;
    protected int m_num;

    public int read_from_file(){}
    public int write_to_file(){}
    public int add_service_history();*/
}
