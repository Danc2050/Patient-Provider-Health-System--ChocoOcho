public class ProviderList {
    /*protected Node p_root;

    public ProviderList(){this.m_root = null;)
    public int read_from_file(){}
    public int write_to_file(){}//TODO Try catch blocks in imp.
    public int add{}
    public int update{}
    public int remove{}*/
}
