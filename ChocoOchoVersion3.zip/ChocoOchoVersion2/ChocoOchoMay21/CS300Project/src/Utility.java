import java.util.Scanner;
public class Utility {
    protected Scanner input;
    public Utility() { input = new Scanner(System.in); }
}
