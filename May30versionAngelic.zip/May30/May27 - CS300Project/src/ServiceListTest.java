/*import junit.framework.TestCase;

public class ServiceListTest extends TestCase {
    ServiceList SL = new ServiceList();

    public ServiceListTest(String name){
        super(name);
    }

    public void setUp() throws Exception {
        super.setUp();
    }

    public void tearDown() throws Exception {
    }

    public void testRead_from_file() {
    }

    public void testWrite_to_file() {
    }

    public void testAdd_service() {
        testAdd_service1();
    }

    public void testAdd_service1() {
        System.out.println("Inserting a new service");
        //ServiceList instance = new ServiceList();
        Service root = new Service("Pharmacist", 12345, 600);
        /*This seems off...
        if(root == null)
            root = (Service) instance.add_service(root, 12345, "Pharmacist", 600);
        else
            fail("The list is not empty");
        if(root != null)
            root = (Service) instance.add_service(root, 12345, "Pharmacist", 600);
        else
            fail("The list is empty");
        root = (Service) instance.add_service(root, 12345, "Pharmacist", 600);
        System.out.println("Inserting an item that already exist");
        Can't get the systemOut().getHistory() to be recognized...
        root = (Service) SL.add_service(root, 12344, "Yoga Trainer", 600);
        root = (Service) SL.add_service(root, 12343, "Weight Trainer", 600);
        root = (Service) SL.add_service(root, 12342, "Therapist", 650);
        SL.display_all(root);
        //String output = systemOut().getHistory();
        //assertEquals("Pharmacist 12345 600\nTherapist 12342 650\nYoga Trainer 12344 600\nWeight Trainer 12343 600\n", output);
    }

    public void testDisplay_all() {
    }

    public void testDisplay_all1() {
    }
}*/